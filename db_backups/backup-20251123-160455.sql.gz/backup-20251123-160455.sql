--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Postgres.app)
-- Dumped by pg_dump version 14.18 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _drizzle_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: _drizzle_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public._drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: _drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public._drizzle_migrations_id_seq OWNED BY public._drizzle_migrations.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    action character varying(100) NOT NULL,
    description character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    category character varying(500)
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    base_unit character varying(50) NOT NULL,
    unit_price character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    last_updated_by character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role_id integer NOT NULL,
    permission_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_system_role boolean DEFAULT false
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock (
    p_code character varying(25) NOT NULL,
    w_code character varying(25) NOT NULL,
    p_instock double precision NOT NULL,
    p_commited double precision NOT NULL,
    p_orderd double precision NOT NULL,
    p_available double precision NOT NULL
);


--
-- Name: tbl_contactPerson; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."tbl_contactPerson" (
    "cpCode" character varying(25) NOT NULL,
    "cpName" character varying(100) NOT NULL,
    "cCode" character varying(25),
    "cTel" character varying(50),
    "cEmail" character varying(50) NOT NULL,
    "cStatus" boolean DEFAULT true,
    "cpCreatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "cpCreatedBy" character varying(25),
    "cpLastUpdateAt" timestamp without time zone DEFAULT now() NOT NULL,
    "cpLastUpdateBy" character varying(25)
);


--
-- Name: tbl_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tbl_customer (
    "cCode" character varying(25) NOT NULL,
    "cName" character varying(100),
    "cDescription" character varying(255),
    "cAddress" character varying(255),
    "cTel" character varying(50),
    "cEmail" character varying(50),
    "cStatus" boolean,
    "cCreatedAt" timestamp without time zone,
    "cCreatedBy" character varying(25),
    "uLastUpdateAt" timestamp without time zone,
    "cLastUpdateBy" character varying(25)
);


--
-- Name: tbl_employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tbl_employee (
    "eCode" character varying(25) NOT NULL,
    "eName" character varying(100),
    "eDescription" character varying(255),
    "eGender" character varying(7),
    "eDOB" date,
    "eAddress" character varying(255),
    "eTel" character varying(50),
    "eEmail" character varying(50),
    "eStatus" boolean,
    "eCreatedAt" timestamp without time zone,
    "eCreatedBy" character varying(25),
    "eLastUpdateAt" timestamp without time zone,
    "eLastUpdateBy" character varying(25)
);


--
-- Name: tbl_quotationHeader; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."tbl_quotationHeader" (
    "qhCode" character varying(15) NOT NULL,
    "qhType" character varying(10),
    "qhStatus" boolean,
    "qhPostingDate" timestamp without time zone,
    "qhValidDate" timestamp without time zone,
    "qlDocDate" timestamp without time zone,
    "cCode" character varying(50),
    "eCode" character varying(50),
    "qhProjectID" character varying(50),
    "qhProjectName" character varying(255),
    "qhPaymentCode" character varying(50),
    "qhPaymentName" character varying(255),
    "qhShipping" character varying(50),
    "qlPicDelDate" timestamp without time zone,
    "qhDestinationCode" character varying(50),
    "qhDestinationName" character varying(255),
    "qhGTotal" numeric(19,2),
    "qhDiscount" numeric(19,2),
    "qhTotal" numeric(19,2),
    "qhCreatedAt" timestamp without time zone,
    "qhCreatedBy" character varying(25),
    "qhLastUpdateAt" timestamp without time zone,
    "qhLastUpdateBy" character varying(25),
    "qhApprovedAt" timestamp without time zone,
    "qhApprovedBy" character varying(25),
    "qhClosedAt" timestamp without time zone,
    "qhClosedBy" character varying(25)
);


--
-- Name: tbl_quotationLine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."tbl_quotationLine" (
    "qlID" integer NOT NULL,
    "qhCode" character varying(15),
    "qlLineNo" integer,
    "qlpCode" character varying(25),
    "qlpName" character varying(100),
    "qlpBaseUnit" character varying(10),
    "qlpUnitPrice" double precision,
    "qlQty" double precision,
    "qlGrandTotal" double precision,
    "qlDiscount" double precision,
    "qlTotal" double precision,
    "qlRemark" character varying(255)
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_by integer,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true
);


--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(200) NOT NULL,
    dob timestamp without time zone,
    phone_number character varying(20),
    password_hash text NOT NULL,
    password_confirmation text NOT NULL,
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    w_code character varying(100) NOT NULL,
    w_description text NOT NULL,
    w_status boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by character varying(100) NOT NULL,
    updated_by character varying(100) NOT NULL
);


--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: _drizzle_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('public._drizzle_migrations_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Data for Name: _drizzle_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._drizzle_migrations (id, hash, created_at) FROM stdin;
1	e307804e2310bd1888264ae372631bd1f8f08e5254fc63a9f41245db79b06ba6	1758351832544
2	3fcdad8a20ce15b4d2bbbb183437df57dc9220864d2ce0c93b873d4410fd6485	1760019091041
3	77f85fe6a0b96cf7e1713cdfe003af9dd424c6181003f7c3fa9693432f002432	1760019138600
4	dda3548eaefbb0e037856914ec4a11933b2babb092bc37f58a60cb3f6150df41	1760366912059
5	b5d15d844c62b24fa44b69b3ba842b6ae33af5fc932f06ed6042611d0daa9de5	1760964368964
6	2ccfa1f253bb5166eb1d780528f1c5eabefbc6955be92c2b962b49d790fd2e0d	1763792867069
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, resource, action, description, created_at, updated_at, category) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, code, name, description, base_unit, unit_price, status, last_updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, slug, description, is_active, created_at, updated_at, is_system_role) FROM stdin;
1	Super Admin	super-admin	Full system access	t	2025-09-18 10:31:51.907558	2025-10-17 04:32:52.223	t
\.


--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock (p_code, w_code, p_instock, p_commited, p_orderd, p_available) FROM stdin;
\.


--
-- Data for Name: tbl_contactPerson; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."tbl_contactPerson" ("cpCode", "cpName", "cCode", "cTel", "cEmail", "cStatus", "cpCreatedAt", "cpCreatedBy", "cpLastUpdateAt", "cpLastUpdateBy") FROM stdin;
CP001	chheng	\N	+1234567890	john@example.com	t	2025-10-20 19:48:47.967001	\N	2025-10-20 12:53:36.548	\N
CP002	John Doe2	\N	+1234567890	john2@example.com	t	2025-11-01 11:50:11.805006	\N	2025-11-01 11:50:11.805006	\N
\.


--
-- Data for Name: tbl_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tbl_customer ("cCode", "cName", "cDescription", "cAddress", "cTel", "cEmail", "cStatus", "cCreatedAt", "cCreatedBy", "uLastUpdateAt", "cLastUpdateBy") FROM stdin;
\.


--
-- Data for Name: tbl_employee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tbl_employee ("eCode", "eName", "eDescription", "eGender", "eDOB", "eAddress", "eTel", "eEmail", "eStatus", "eCreatedAt", "eCreatedBy", "eLastUpdateAt", "eLastUpdateBy") FROM stdin;
\.


--
-- Data for Name: tbl_quotationHeader; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."tbl_quotationHeader" ("qhCode", "qhType", "qhStatus", "qhPostingDate", "qhValidDate", "qlDocDate", "cCode", "eCode", "qhProjectID", "qhProjectName", "qhPaymentCode", "qhPaymentName", "qhShipping", "qlPicDelDate", "qhDestinationCode", "qhDestinationName", "qhGTotal", "qhDiscount", "qhTotal", "qhCreatedAt", "qhCreatedBy", "qhLastUpdateAt", "qhLastUpdateBy", "qhApprovedAt", "qhApprovedBy", "qhClosedAt", "qhClosedBy") FROM stdin;
\.


--
-- Data for Name: tbl_quotationLine; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."tbl_quotationLine" ("qlID", "qhCode", "qlLineNo", "qlpCode", "qlpName", "qlpBaseUnit", "qlpUnitPrice", "qlQty", "qlGrandTotal", "qlDiscount", "qlTotal", "qlRemark") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assigned_at, expires_at, is_active) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, code, name, dob, phone_number, password_hash, password_confirmation, is_active, is_verified, created_at, updated_at) FROM stdin;
4	chheng@gmail.com	CHHENG_001	chheng	\N		$2b$12$/LLh.XelWnOF2bOS1bK9x.X1i1A8QWea8ZE6l1zqfo9gjFzdQ6U4y		t	t	2025-08-26 22:21:18.554625	2025-10-17 08:11:36.064
23	test@gmail.com	0023	test	\N		$2b$12$NJXSdFmqiiKzdSt72ybtX.le7OEB5XnwAA5KMUp1exqF93t1P8suy	$2b$12$NJXSdFmqiiKzdSt72ybtX.le7OEB5XnwAA5KMUp1exqF93t1P8suy	t	f	2025-10-17 20:29:57.053648	2025-11-22 04:18:35.89
25	admin@test.com	TEST001	Test Admin	\N	\N	b2dqdyMAChlBWOAfGLDqrleCFoUvsj092Lemni2jOTvMNwlrOSfzIO	b2dqdyMAChlBWOAfGLDqrleCFoUvsj092Lemni2jOTvMNwlrOSfzIO	t	t	2025-11-23 13:50:03.165097	2025-11-23 13:50:03.165097
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, w_code, w_description, w_status, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Name: _drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public._drizzle_migrations_id_seq', 6, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 58, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 385, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 13, true);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 19, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 25, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 1, false);


--
-- Name: _drizzle_migrations _drizzle_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._drizzle_migrations
    ADD CONSTRAINT _drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_unique UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: products products_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_code_unique UNIQUE (code);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- Name: tbl_contactPerson tbl_contactPerson_cEmail_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_contactPerson"
    ADD CONSTRAINT "tbl_contactPerson_cEmail_unique" UNIQUE ("cEmail");


--
-- Name: tbl_contactPerson tbl_contactPerson_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_contactPerson"
    ADD CONSTRAINT "tbl_contactPerson_pkey" PRIMARY KEY ("cpCode");


--
-- Name: tbl_customer tbl_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_customer
    ADD CONSTRAINT tbl_customer_pkey PRIMARY KEY ("cCode");


--
-- Name: tbl_employee tbl_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_employee
    ADD CONSTRAINT tbl_employee_pkey PRIMARY KEY ("eCode");


--
-- Name: tbl_quotationHeader tbl_quotationHeader_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_pkey" PRIMARY KEY ("qhCode");


--
-- Name: tbl_quotationLine tbl_quotationLine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationLine"
    ADD CONSTRAINT "tbl_quotationLine_pkey" PRIMARY KEY ("qlID");


--
-- Name: stock tbl_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT tbl_stock_pkey PRIMARY KEY (p_code);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_code_unique UNIQUE (code);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_w_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_w_code_unique UNIQUE (w_code);


--
-- Name: role_permissions role_permissions_permission_id_permissions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_permissions_id_fk FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: tbl_contactPerson tbl_contactPerson_cCode_tbl_customer_cCode_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_contactPerson"
    ADD CONSTRAINT "tbl_contactPerson_cCode_tbl_customer_cCode_fk" FOREIGN KEY ("cCode") REFERENCES public.tbl_customer("cCode");


--
-- Name: tbl_contactPerson tbl_contactPerson_cpCreatedBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_contactPerson"
    ADD CONSTRAINT "tbl_contactPerson_cpCreatedBy_users_code_fk" FOREIGN KEY ("cpCreatedBy") REFERENCES public.users(code);


--
-- Name: tbl_contactPerson tbl_contactPerson_cpLastUpdateBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_contactPerson"
    ADD CONSTRAINT "tbl_contactPerson_cpLastUpdateBy_users_code_fk" FOREIGN KEY ("cpLastUpdateBy") REFERENCES public.users(code);


--
-- Name: tbl_customer tbl_customer_cCreatedBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_customer
    ADD CONSTRAINT "tbl_customer_cCreatedBy_users_code_fk" FOREIGN KEY ("cCreatedBy") REFERENCES public.users(code);


--
-- Name: tbl_customer tbl_customer_cLastUpdateBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_customer
    ADD CONSTRAINT "tbl_customer_cLastUpdateBy_users_code_fk" FOREIGN KEY ("cLastUpdateBy") REFERENCES public.users(code);


--
-- Name: tbl_employee tbl_employee_eCreatedBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_employee
    ADD CONSTRAINT "tbl_employee_eCreatedBy_users_code_fk" FOREIGN KEY ("eCreatedBy") REFERENCES public.users(code);


--
-- Name: tbl_employee tbl_employee_eLastUpdateBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_employee
    ADD CONSTRAINT "tbl_employee_eLastUpdateBy_users_code_fk" FOREIGN KEY ("eLastUpdateBy") REFERENCES public.users(code);


--
-- Name: tbl_quotationHeader tbl_quotationHeader_cCode_tbl_customer_cCode_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_cCode_tbl_customer_cCode_fk" FOREIGN KEY ("cCode") REFERENCES public.tbl_customer("cCode");


--
-- Name: tbl_quotationHeader tbl_quotationHeader_eCode_tbl_employee_eCode_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_eCode_tbl_employee_eCode_fk" FOREIGN KEY ("eCode") REFERENCES public.tbl_employee("eCode");


--
-- Name: tbl_quotationHeader tbl_quotationHeader_qhApprovedBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_qhApprovedBy_users_code_fk" FOREIGN KEY ("qhApprovedBy") REFERENCES public.users(code);


--
-- Name: tbl_quotationHeader tbl_quotationHeader_qhClosedBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_qhClosedBy_users_code_fk" FOREIGN KEY ("qhClosedBy") REFERENCES public.users(code);


--
-- Name: tbl_quotationHeader tbl_quotationHeader_qhCreatedBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_qhCreatedBy_users_code_fk" FOREIGN KEY ("qhCreatedBy") REFERENCES public.users(code);


--
-- Name: tbl_quotationHeader tbl_quotationHeader_qhLastUpdateBy_users_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationHeader"
    ADD CONSTRAINT "tbl_quotationHeader_qhLastUpdateBy_users_code_fk" FOREIGN KEY ("qhLastUpdateBy") REFERENCES public.users(code);


--
-- Name: tbl_quotationLine tbl_quotationLine_qhCode_tbl_quotationHeader_qhCode_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."tbl_quotationLine"
    ADD CONSTRAINT "tbl_quotationLine_qhCode_tbl_quotationHeader_qhCode_fk" FOREIGN KEY ("qhCode") REFERENCES public."tbl_quotationHeader"("qhCode");


--
-- Name: user_roles user_roles_assigned_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_users_id_fk FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

